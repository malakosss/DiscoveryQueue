# -*- coding: utf-8 -*-
"""
Created on Fri Jan 21 23:35:58 2022

@author: MRWal
"""

import tailored as tai

def logo():
    print("\n===========================================================================================================================================")
    print("  ______      _____    _____   _____      ____      __    __    _____   __    __    _____                                                     ") 
    print(" (_  __ \    / ___/   / ___/  (  __ \    / __ \     ) )  ( (   / ___/   ) )  ( (   / ___/                                                    ")
    print("   ) ) \ \  ( (__    ( (__     ) )_) )  / /  \ \   ( (    ) ) ( (__    ( (    ) ) ( (__                                                      ")
    print("  ( (   ) )  ) __)    ) __)   (  ___/  ( (    ) )   ) )  ( (   ) __)    ) )  ( (   ) __)                                                     ")
    print("   ) )  ) ) ( (      ( (       ) )     ( (  /\) )  ( (    ) ) ( (      ( (    ) ) ( (                                                        ")
    print("  / /__/ /   \ \___   \ \___  ( (       \ \_\ \/    ) \__/ (   \ \___   ) \__/ (   \ \___                                                    ")
    print(" (______/     \____\   \____\ /__\       \___\ \_   \______/    \____\  \______/    \____\                                                   ")
    print("                                              \__)                                                              ")
    print("                                                              \    / ___  __   __     __           __        ___")
    print("                                                               \  / |__  |__) /__` | /  \ |\ |    /  \ |\ | |__ ")
    print("                                                                \/  |___ |  \ .__/ | \__/ | \|    \__/ | \| |___ ")
    print("\n __                                     __   __   __ ")
    print("|__) \ / .    |\/|  /\  |     /\  |__/ /  \ /__` /__` ")
    print("|__)  |  .    |  | /~~\ |___ /~~\ |  \ \__/ .__/ .__/ ")
    print("\n===========================================================================================================================================\n")


def buildTrackList(artistList):
    trackList = []
    
    selectionMode = str(input("\nWould you like to include songs that the selected Artists \'appear on\'? \n YES (Y) or NO (N)\n\n  This can deliver some unexpected, wayward results... \n  --> ")).upper()
    
    sessionDiscography = []
    for artist in artistList:
        artist_id = sp.search(artist, limit=1, offset=0, type='artist')['artists']['items'][0]['uri']
        sessionDiscographyIDs = sp.artist_albums(artist_id, album_type="album", limit=50)['items']
        sessionDiscographyIDs += sp.artist_albums(artist_id, album_type="single", limit=50)['items']
        
        if selectionMode in ["Y","YES"]:
            sessionDiscographyIDs += sp.artist_albums(artist_id, album_type="appears_on", limit=50)['items']
            
        for item in sessionDiscographyIDs:
            sessionDiscography += sp.album_tracks(item['id'])['items']
        
    for item in sessionDiscography:
        trackList.append(item['id'])
        
    return list(set(trackList))
        
def queueBuild_DeepDive(sp, trackList, playlistFeatures):
    print("\n Starting to build queue now...")
    print("\n     ~Choosing from " + str(len(trackList)) + " songs!~ \n")
    for songID in trackList:
        if tai.meetSpec(sp, playlistFeatures, songID):
            try:
                sp.add_to_queue(songID)
            except:
                print("INVALID TRACK AVOIDED")
                continue
            
            print("     Track added!")

def start(token):
    logo()
    
    global sp
    sp = token
    
    # (1) Define the playlist to have to deep dive tailored around
    chosenPlaylist = tai.choosePlaylists(sp.current_user_playlists())
    baselineFeatures = tai.playlistAnalysis(sp, chosenPlaylist['name'], sp.playlist_items(chosenPlaylist['id'])['items'])
    
    # (2) Define the Artists that the deep dive should be centered around 
    rawChosenArtists = str(input("\nDecide the artist(s) that you'd like to deep-dive into: \n If you wish to choose multiple artists, use the \'//\' symbol between artists w/ no space \n  For example --> Sylvan LaCue//Angie McMahon//DMX \n\n  --> "))
    chosenArtists = rawChosenArtists.split("//", maxsplit=-1)
    
    # (3) Build possible track list
    trackList = buildTrackList(chosenArtists)
    
    # (4) Build queue based on chosen Artists discography
    queueBuild_DeepDive(sp, trackList, baselineFeatures)





