# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 21:20:19 2022

@author: MRWal
"""
import discovery
import tailored
from tabulate import tabulate

def main():
    jobOnGoing = True
    options = [[1, "DiscoveryQueue", "DiscoveryQueue will build you a queue of unique music based on a selected Starting Artist"], 
               [2, "TailoredQueue", "TailoredQueue works to expedite your playlist creation by queueing songs that 'fit' your playlist"]]
    
    while(jobOnGoing):
        print("\n")
        print(tabulate(options, headers=["Option", "Process", "Description"]))
        processChoice = int(input("\nDefine the process by number you'd like to make use of: "))
        
        if processChoice == 1:
            discovery.start()
        elif processChoice == 2:
            tailored.start()
        else:
            print("/n ~Invalid Choice!~")
            continue
        
        if str(input("\nWould you like to continue using the program? (Enter Yes (Y) or No (N) \n\n--> ")).upper() in ["NO", "N"]:
            jobOnGoing = False

if __name__ == "__main__":
    main()


