# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 21:20:19 2022

@author: MRWal
"""
import discovery
import tailored

from tabulate import tabulate
import traceback
import sys
import os
import spotipy
from spotipy.oauth2 import SpotifyOAuth

os.environ["SPOTIPY_CLIENT_ID"] = "391ed8cdb24c443db390ac0d15d1076f"
os.environ["SPOTIPY_CLIENT_SECRET"] = "ab24e70cdb5446d2af9fc5234a8126cc"
os.environ["SPOTIPY_REDIRECT_URI"] = "http://localhost:8888/callback"

def main():
    jobOnGoing = True
    options = [[1, "DiscoveryQueue", "DiscoveryQueue will build you a queue of unique music based on a selected Starting Artist"], 
               [2, "TailoredQueue", "TailoredQueue works to expedite your playlist creation by queueing songs that 'fit' your playlist"]]
    
    #DeepQueue
    
    scope = "user-read-currently-playing user-modify-playback-state playlist-read-private"
    token = spotipy.Spotify(auth_manager=SpotifyOAuth(scope=scope, cache_path="user.cache"))
    
    while(jobOnGoing):
        print("\n")
        print(tabulate(options, headers=["Option", "Process", "Description"]))
        try:
            processChoice = int(input("\nDefine the process by number you'd like to make use of: "))
            if processChoice == 1:
                discovery.start(token)
            elif processChoice == 2:
                tailored.start(token)
            elif processChoice == 99:
                #Bug Fix --> reset token
                os.remove("user.cache")
                scope = "user-read-currently-playing"
                token = spotipy.Spotify(auth_manager=SpotifyOAuth(scope=scope, cache_path="user.cache"))
                token.current_user_playlists()
                os.remove("user.cache")
                break
            else:
                print("\n\n\n ~Invalid Choice!~ \n\n")
                continue
        except:
            print("\n===========================================================================================================================================\n")
            traceback.print_exc()
            input("\n\n\n --> Press any button to continue <--")
            sys.exit()
        
        if str(input("\nWould you like to continue using the program? (Enter Yes (Y) or No (N) \n\n--> ")).upper() in ["NO", "N"]:
            jobOnGoing = False

if __name__ == "__main__":
    main()


