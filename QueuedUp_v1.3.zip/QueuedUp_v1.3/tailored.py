# -*- coding: utf-8 -*-
"""
Created on Fri Dec 31 17:25:31 2021

@author: MRWal
"""
import spotipy
import os
import random

from spotipy.oauth2 import SpotifyOAuth
from tabulate import tabulate
import discovery as d

os.environ["SPOTIPY_CLIENT_ID"] = "391ed8cdb24c443db390ac0d15d1076f"
os.environ["SPOTIPY_CLIENT_SECRET"] = "ab24e70cdb5446d2af9fc5234a8126cc"
os.environ["SPOTIPY_REDIRECT_URI"] = "http://localhost:8888/callback"

checkOneFailures = 0
checkTwoFailures = 0
checkThreeFailures = 0
checkFourFailures = 0

global DEBUG
DEBUG = True

def logo():
    print("\n===========================================================================================================================================")
    print(" ________         __  __                                      __         ______                                          ")
    print("/        |       /  |/  |                                    /  |       /      \                                         ")                                     
    print("$$$$$$$$/______  $$/ $$ |  ______    ______    ______    ____$$ |      /$$$$$$  | __    __   ______   __    __   ______  ")
    print("   $$ | /      \ /  |$$ | /      \  /      \  /      \  /    $$ |      $$ |  $$ |/  |  /  | /      \ /  |  /  | /      \ ")
    print("   $$ | $$$$$$  |$$ |$$ |/$$$$$$  |/$$$$$$  |/$$$$$$  |/$$$$$$$ |      $$ |  $$ |$$ |  $$ |/$$$$$$  |$$ |  $$ |/$$$$$$  |")
    print("   $$ | /    $$ |$$ |$$ |$$ |  $$ |$$ |  $$/ $$    $$ |$$ |  $$ |      $$ |_ $$ |$$ |  $$ |$$    $$ |$$ |  $$ |$$    $$ |")
    print("   $$ |/$$$$$$$ |$$ |$$ |$$ \__$$ |$$ |      $$$$$$$$/ $$ \__$$ |      $$ / \$$ |$$ \__$$ |$$$$$$$$/ $$ \__$$ |$$$$$$$$/ ")
    print("   $$ |$$    $$ |$$ |$$ |$$    $$/ $$ |      $$       |$$    $$ |      $$ $$ $$< $$    $$/ $$       |$$    $$/ $$       |")
    print("   $$/  $$$$$$$/ $$/ $$/  $$$$$$/  $$/        $$$$$$$/  $$$$$$$/        $$$$$$  | $$$$$$/   $$$$$$$/  $$$$$$/   $$$$$$$/ ")
    print("                                                                            $$$/                                         ")
    print("                                                                                         \    / ___  __   __     __           __        ___")
    print("                                                                                          \  / |__  |__) /__` | /  \ |\ |    /  \ |\ | |__ ")
    print("                                                                                           \/  |___ |  \ .__/ | \__/ | \|    \__/ | \| |___ ")
    print("\n __                                     __   __   __ ")
    print("|__) \ / .    |\/|  /\  |     /\  |__/ /  \ /__` /__` ")
    print("|__)  |  .    |  | /~~\ |___ /~~\ |  \ \__/ .__/ .__/ ")
    print("\n===========================================================================================================================================")



def choosePlaylists(userPlaylists):
    
    data = []
    index = 0
    
    for playlist in userPlaylists['items']:
        data.append([index, playlist['name']])
        index += 1
        
    print(tabulate(data, headers=["Index", "PlaylistName"]))
    playlistChoice = int(input("\nDefine the index of the playlist you want to build a queue around: \n\n--> "))
    
    return userPlaylists['items'][playlistChoice]
    
def playlistAnalysis(playlistName, tracks):
    # (1) Define list of playlist song IDs --> need to solve if over 100 tracks (need check)
    
    trackIDs = []
    numOfTracks = 0
    for track in tracks:
        trackIDs.append(track['track']['id'])
        numOfTracks += 1
        
    # (2) Run each track through audio analysis and sum up all their values
    # featuresList = [acousticness, danceability, energy, instrumentalness, key, loudness, speechiness, mode, valence, tempo]
    playlistFeatures = [['acousticness',0],
                        ['danceability',0],
                        ['energy',0],
                        ['instrumentalness',0],
                        ['speechiness',0],
                        ['mode',0],
                        ['valence',0],
                        ['tempo',0],
                        ['key',0],
                        ['loudness',0]]
    
    for songID in trackIDs:
        trackFeatures = sp.audio_features(songID)[0]
        
        # (a) acousticness
        playlistFeatures[0][1] += trackFeatures['acousticness']
        
        # (b) danceability
        playlistFeatures[1][1] += trackFeatures['danceability']
        
        # (c) energy
        playlistFeatures[2][1] += trackFeatures['energy']
        
        # (d) instrumentalness
        playlistFeatures[3][1] += trackFeatures['instrumentalness']
        
        # (e) key
        playlistFeatures[8][1] += trackFeatures['key']
        
        # (f) loudness
        playlistFeatures[9][1] += trackFeatures['loudness']
        
        # (g) speechiness
        playlistFeatures[4][1] += trackFeatures['speechiness']
        
        # (h) mode
        playlistFeatures[5][1] += trackFeatures['mode']
        
        # (i) valence
        playlistFeatures[6][1] += trackFeatures['valence']
        
        # (j) tempo
        playlistFeatures[7][1] += trackFeatures['tempo']
    
    # (3) Find average playlist features
    playlistFeatures[:] = [[x[0], x[1] / numOfTracks] for x in playlistFeatures]
    
    # (4) Display average playlist features in tables
    print('\n Playlist: ' + playlistName + '\n')
    print(tabulate(playlistFeatures, headers=["Feature", "AverageValue"]))
    
    return playlistFeatures

def deriveRelatedArtists(sp, chosenPlaylistID):
    
    playlistSongs = sp.playlist_items(chosenPlaylistID)['items']
    listOfArtists = []
    
    for song in playlistSongs:
        listOfArtists.append(song['track']['artists'][0]['name']) 
    
    print("\nThere are a total of ~" + str(len(listOfArtists)) + "~ artists in your selected playlist")
    numOfIterations = int(input("\n>How many random artists from your selected playlist would you like to be used to build your tailored Queue? \n>Each artist chosen translates to a total of 200 songs to be scanned \n>Enter 0 if you would like all artsts to be used \n--> "))
    
    if numOfIterations == 0:
        numOfIterations = len(listOfArtists)

    relatedArtists = []
    selections = []
    for a in range(0, numOfIterations):
        selection = random.randint(0, (len(listOfArtists) - 1))
        if selection not in selections:
            artistsToBeAdded = d.investigateArtist(sp, listOfArtists[selection])
            selections.append(selection)
            for item in artistsToBeAdded:
                if item not in relatedArtists:
                    relatedArtists.append(item)
        else:
            print("\n")
            print(selection)
            print(selections)
            print("\n")
            a -= 1

    return relatedArtists

def meetSpec(sp, playlistFeatures, songID):
    checks = [True, True, True, True]
    trackFeatures = sp.audio_features(songID)[0]
    #essentialFeatures = ["acousticness", "danceability", "energy", "instrumentalness", "key", "loudness", "speechiness", "valence", "tempo"]
    checkOneFeatures = ["acousticness", "danceability", "energy", "instrumentalness", "speechiness", "valence"]
    
    # (Check 1) Investigate everything but key, loudness, and tempo
    passTest = True
    iterable = 0
    
    global checkOneFailures
    global checkTwoFailures
    global checkThreeFailures
    global checkFourFailures
    
    # Update #1 --> make the parameters dynamic in some sense
    while(passTest and (iterable != len(checkOneFeatures))):
        if(abs(playlistFeatures[iterable][1] - trackFeatures[checkOneFeatures[iterable]]) > .225): #seemingly critical, may be worthwhile to see what differs the most
            passTest = False
            checks[0] = False
            checkOneFailures += 1
        else:
            iterable += 1
            
    # (Check 2) Investiate key
    if(abs(playlistFeatures[8][1] - trackFeatures['key']) > 2):
        checks[1] = False
        checkTwoFailures += 1
        
    # (Check 3) Investigate loudness
    if(abs(playlistFeatures[9][1] - trackFeatures['loudness']) > 5):
        checks[2] = False
        checkThreeFailures += 1
        
    # (Check 3) Investigate tempo
    if(abs(playlistFeatures[7][1] - trackFeatures['tempo']) > 15):
        checks[3] = False
        checkFourFailures += 1
        
    # Report Results
    if False in checks:
        return False
    else:
        return True

def queueBuild_EvaluateFeatures(sp, relatedArtists, playlistFeatures, countryCode):
    print("\n")
    for artist in range(0, len(relatedArtists)):
        related_id = relatedArtists[artist]['uri']
        topTen = sp.artist_top_tracks(related_id, country=countryCode)['tracks']
        for song in range(0, len(topTen)):
            if meetSpec(sp, playlistFeatures, topTen[song]['uri']):
                sp.add_to_queue(topTen[song]['uri'])
                print("Adding track titled --> " + topTen[song]['name'])

def start():
    logo()
    scope = "user-read-currently-playing user-modify-playback-state playlist-read-private"
    
    global sp
    sp = spotipy.Spotify(auth_manager=SpotifyOAuth(scope=scope, cache_path="user.cache"))
    
    # (1) Define the playlist to have to queue tailored around
    chosenPlaylist = choosePlaylists(sp.current_user_playlists())
    baselineFeatures = playlistAnalysis(chosenPlaylist['name'], sp.playlist_items(chosenPlaylist['id'])['items'])
    
    # (2) Produce the related artists list
    countryCode = str(input("\nAll the songs that are used to build the queue are determined by country. Define which country you would like to use: \n (use ISO 3166-1 alpha-2 country codes) \n  (i.e., US or GB or DE) \n\n--> ")).upper()
    relatedArtists = deriveRelatedArtists(sp, chosenPlaylist['id'])
    
    # (3) Build the Queue (with songs that meet requirements)
    queueBuild_EvaluateFeatures(sp, relatedArtists, baselineFeatures, countryCode)
    
    if DEBUG:
        print("\nFailures at Check #1 --> " + checkOneFailures)
        print("Failures at Check #2 --> " + checkTwoFailures)
        print("Failures at Check #3 --> " + checkThreeFailures)
        print("Failures at Check #4 --> " + checkFourFailures)